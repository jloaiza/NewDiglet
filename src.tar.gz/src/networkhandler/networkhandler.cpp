#include "networkhandler.h"

NetworkHandler::NetworkHandler()
{
    _sockfd = 0;
    FD_ZERO(&_master);
    FD_ZERO(&_read_fds);
    connectRequest(&_sockfd, &_my_addr);
    FD_SET(_sockfd, &_master);
    _fdmax = _sockfd;
    _indicatorMessage = 0;
    _run = true;
}

int NetworkHandler::meetClient(int pI, fd_set* pMaster, int pSockfd, int pFdmax)
{
    int nbytes_recvd, j;
    char recv_buf[BUFSIZE];
    memset(recv_buf, 0, BUFSIZE);
    if ((nbytes_recvd = recv(pI, recv_buf, BUFSIZE, 0)) <= 0) 
    {
        if (nbytes_recvd == 0) 
        {
            std::cout << "ATENCIÓN: Se ha desconectado el cliente con el socket: " << pI <<  "." << std::endl;
        }
        else 
        {
            Error(7,"ATENCIÓN: Se realizo una conexión incorrecta, el servidor la ha rechazado para mantener la estabilidad del sistema.");
        }
        close(pI);
        FD_CLR(pI, pMaster);
    }
    /* Se convierte el _inBuffer de char a string para un manejo más fácil. */
    std::string inMessageBuffer = recv_buf;

    /* Se envia el mensaje a otro método para su posterior evaluación. */
    inMessage(inMessageBuffer, pI, pMaster);
}

void NetworkHandler::outMessage(std::string pMessage, int pSocket)
{
    char _inBuffer[BUFSIZE];
    const char *pMessageOut = pMessage.c_str();
    memset(_inBuffer, 0, BUFSIZE);
    sprintf(_inBuffer, pMessageOut); 
    if((_byteCount = send(pSocket, _inBuffer, strlen(_inBuffer), 0))== -1)
    {
        Error(8, "ATENCIÓN: No se pudo enviar la información al destino.");
    }
}

void NetworkHandler::acceptConnection(fd_set* pMaster, int* pFdmax, int pSockfd, struct sockaddr_in* pClient_addr)
{
    socklen_t addrlen;
    int newsockfd;
    addrlen = sizeof(struct sockaddr_in);
    if((newsockfd = accept(pSockfd, (struct sockaddr *)pClient_addr, &addrlen)) == -1) 
    {
        Error(6, "No se pudo aceptar la conexión entrante, inténtelo de nuevo.");
    }
    else 
    {
        FD_SET(newsockfd, pMaster);
        if(newsockfd > *pFdmax)
        {
            *pFdmax = newsockfd;
        }
        std::cout << "Nueva conexión entrante con IP " << inet_ntoa(pClient_addr->sin_addr) << " por el puerto " << ntohs(pClient_addr->sin_port) << "." <<std::endl; 
        _indicatorMessage = 0;
        WaitConnectionMsg(_indicatorMessage);
    }
}

void NetworkHandler::Error(int pCode, std::string pSpecification)
{
    std::cout << "Error con codigo: " << pCode << " | " << " Especificación: " << pSpecification << std::endl;
}

void NetworkHandler::WaitConnectionMsg(int pLoop)
{
    if (pLoop == 0)
    {
        std::cout << "[SERVER] Esperando conexión: " << std::endl;
        _indicatorMessage++;
    }
}

void NetworkHandler::connectRequest(int* pSockfd, struct sockaddr_in* pMy_addr)
{
    int yes = 1;           
    if ((*pSockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) 
    {
        Error(2,"No se pudo crear el socket correctamente, error en la configuración del sistema.");
    }
    pMy_addr->sin_family = AF_INET;
    pMy_addr->sin_port = htons(PORT);
    pMy_addr->sin_addr.s_addr = INADDR_ANY;
    memset(pMy_addr->sin_zero, '\0', sizeof pMy_addr->sin_zero);  
    if (setsockopt(*pSockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) 
    {
        Error(3, "No se pudo setear el socket correctamente, error en la configuración del sistema.");
    }
    if (bind(*pSockfd, (struct sockaddr *)pMy_addr, sizeof(struct sockaddr)) == -1) 
    {
        Error(4, "No se pudo unir el socket a la direción, error en la configuración del sistema.");
    }
    if (listen(*pSockfd, 10) == -1) 
    {
        Error(5, "No se pudo poner el servidor en escucha, error en la configuración del sistema.");
    }
    WaitConnectionMsg(_indicatorMessage);  
    fflush(stdout);
}

void NetworkHandler::verifyNewConnection()
{
    _read_fds = _master;
    if(select(_fdmax+1, &_read_fds, NULL, NULL, NULL) == -1)
    {
        Error(1, "No se pudo seleccionar la nueva conexión entrante, reintentelo.");
    }
    for (_i = 0; _i <= _fdmax; _i++)
    {
        if (FD_ISSET(_i, &_read_fds))
        {
            if (_i == _sockfd)
            {
                acceptConnection(&_master, &_fdmax, _sockfd, &_client_addr);
            }
            else
            {
                meetClient(_i, &_master, _sockfd, _fdmax);
            }
        }
    }
}

std::string NetworkHandler::getClientIP()
{
    return inet_ntoa(_client_addr.sin_addr);
}

void NetworkHandler::disconnectClient(int pSocket, fd_set* pClear)
{
   std::cout << "ATENCIÓN: Se esta desconectando el cliente cuyo socket corresponde a: " << pSocket << "." << std::endl;
   close(pSocket);
   std::cout << "Cliente desconectado correctamente, el sistema permanece estable." << std::endl;
   FD_CLR(pSocket, pClear);
}

void NetworkHandler::closeServer()
{
    std::cout << "ATENCIÓN: Se ha pedido el CIERRE del servidor principal por parte de algún usuario, todos los clientes serán desconectados, el sistema se cerrara de inmediato." << std::endl;
    _run = false;
}

void NetworkHandler::Run()
{   
    while(_run)
    {   
        verifyNewConnection();
    }
    close(_fdmax);
}

void NetworkHandler::callRun(NetworkHandler* pHandler)
{
    pHandler->Run();
}

void NetworkHandler::start()
{
    _thread = new std::thread(callRun, this);
}

std::thread* NetworkHandler::getThread()
{
    return _thread;
}


