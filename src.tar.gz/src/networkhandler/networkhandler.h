
#ifndef NETWORK_HANDLER
#define NETWORK_HANDLER 



#include <fcntl.h>
#include <string>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include <netinet/in.h>
#include <resolv.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <iostream>
#include <thread>

/* Puerto  de la conexión. */
#define PORT 9999

/* Tamaño del buffer. */
#define BUFSIZE 512

class NetworkHandler
{
    public:  
        NetworkHandler(); 
        void start();
        std::thread* getThread();
        std::thread* _thread;
        void closeServer();
        std::string getClientIP();
    protected:
        virtual void inMessage(std::string pMessage, int pSocket, fd_set* pClear) = 0;     
        void outMessage(std::string pMessage, int pSocket);    
        void disconnectClient(int pSocket, fd_set* pClear);
    private:
        static void callRun(NetworkHandler* pHandler);
        void Run();
        void WaitConnectionMsg(int pLoop);
        void Error(int pCode, std::string pSpecification);
        void verifyNewConnection();
        void connectRequest(int* pSockfd, struct sockaddr_in* pMy_addr);
        void acceptConnection(fd_set* pMaster, int* pFdmax, int pSockfd, struct sockaddr_in* pClient_addr);
        int meetClient(int pI, fd_set* pMaster, int pSockfd, int pFdmax);

        fd_set _master;
        fd_set _read_fds;

        int _run;
        int _indicatorMessage;
        int _byteCount;
        int _fdmax; 
        int _i;
        int _sockfd;

        struct sockaddr_in _my_addr;
        struct sockaddr_in _client_addr;
};

#endif
