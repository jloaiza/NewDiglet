#ifndef RAIDONE
#define RAIDONE

#include "diskgroup.h"
#include "../structures/doublelinkedlist/listnode.h"
#include <string>

class RaidOne : public DiskGroup{
public:

	RaidOne(std::string pID, int pBlockSize);
	RaidOne(std::string pID, int pBlockSize, int pMaxSize, bool pFunctional, bool pWorking);

	void startDiskGroup();
	
	void stopDiskGroup();
	
	DataNode* getFile(iFile* pFile);

	ListNode<Disk>* getNextDisk(ListNode<Disk>* pActual);

	void deleteFile(nTreeNode* pNode);

	nTreeNode* createFile(nTreeNode* pActual, std::string pName, RegisterSpace* pRegister, std::string pUser);	

	short apendReg(DataNode* pData, iFile* pFile);

	short writeReg(int pRegisterNumber, DataNode* pData, iFile* pFile);

	DataNode* readReg(int pRegisterNumber, iFile* pFile);

	void eraseReg(int pRegisterNumber, iFile* pFile);

	RegisterSpace* getRegFormat(iFile* pFile);

	void format();

private:
	static const int DATA_REGFLAG = 0;
	static const int FREE_REGFLAG = 0;

	static const std::string ERROR_READING; //Variable a devolver en las lecturas internas fallidas
	static const int FILENAME_SIZE = 75;	//Tamaño para el nombre del archivo
	static const int AUTHOR_SIZE = 25;	 	//Tamaño para el usuario
	static const int REGS_SIZE = 2; 		//Tamaño del formato de registro
	static const int DIRTOREG_SIZE = 14; 	//Tamaño del puntero de un registro a otro

	static const int REGISTER_SIZE = 27; 	//Tamaño de un registro (columna) individual, debe ser REGCOL_SIZE + REGTYPE_SIZE + REGCOLSIZE
	static const int REGCOL_SIZE = 25; 		//Tamaño para el nombre de columna
	static const int REGTYPE_SIZE = 1; 		//Tamaño para el tipo de dato almacenado
	static const int REGCOLSIZE_SIZE = 1;	//Tamaño para el tamaño del dato

	static const int BLOCKNEXT_SIZE = 10; 	//Tamaño para puntero a siguiente bloque: IP = 4bytes, DISKID = 2bytes, BLOCK = 4bytes

	ListNode<Disk>* _currentDisk;

	void eraseFile(iFile* pFile);

	std::string getHeaderSpace(iFile* pFile, int pPrevSize, int pReadSize);
	std::string getFreeReg(iFile* pFile);
	std::string getLastReg(iFile* pFile);
	std::string getEndReg(iFile* pFile);
	std::string getDataStartDirection(iFile* pFile);
	std::string getBinFromDirection(std::string pDirection);

	void writeLastData(iFile* pFile, std::string pData);
	void writeDataStart(iFile* pFile, std::string pData);
	void writeFreeSpace(iFile* pFile, std::string pData);	
	void writeEndSpace(iFile* pFile, std::string pData);	
	void writeToHeader(iFile* pFile, int pOffset, int pSize, std::string pData);
	std::string getDirectionBlockFromBin(std::string pBin);
};

#endif /* RAIDONE */