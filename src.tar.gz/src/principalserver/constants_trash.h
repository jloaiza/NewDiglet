#ifndef CONSTANTS
#define CONSTANTS

int INT_TYPE    = 0;
int LONG_TYPE   = 1;
int STRING_TYPE = 2;
int DOUBLE_TYPE = 3;
int SHORT_TYPE  = 4;
int SEEK_POS    = -1;
int NO_SESSION  = -1;


#endif /* CONSTANTS */