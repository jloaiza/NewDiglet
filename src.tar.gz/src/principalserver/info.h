#ifndef INFO
#define INFO

#include <string>

std::string lssmenuL = "** * * * * * * * * * * * * * * * * *";
std::string lssmenuS = "*                                  *";
std::string lssmenu3 = "*     seleccione la operacion:     *";
std::string lssmenu4 = "*       1. Crear DiscGroup         *";
std::string lssmenu5 = "*       2. Borrar DiskGroup        *";
std::string lssmenu6 = "*       3. Mostrar DiskGroups      *";
std::string lssmenu7 = "*       4. SAVE                    *";
std::string lssmenu8 = "*       5. LOAD                    *";
std::string lssmenu9 = "*       6. Salir                   *";

std::string NAME = "ID del diskgroup: ";
std::string NAME2 = "nombre del xml: ";
std::string SIZE = "tamaño del bloque (bytes): ";
std::string PASS = "security key: ";



std::string lssmenu10 = "*       1. Agregar disco           *";
std::string lssmenu11 = "*       2. Salir                   *";

std::string DISKID = "cual es la ID del disco (IP e ID): ";


#endif 
