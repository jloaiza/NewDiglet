
#include <iostream>

int main(int argc, char **argv)
{
	char* tmp = new char[2];
	return 0;
}

