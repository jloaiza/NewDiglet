#include "datanode.h"

void DataNode::releaseDependencyList(){
	DataNode* iNode = this;
	while (iNode != 0){
		DataNode* tmp = iNode->getNext();
		delete iNode;
		iNode = tmp;
	}
}

int DataNode::getAllDataSize(){
	DataNode* iNode = this;
	int size = 0;
	while (iNode != 0){
		size += iNode->getSize();
		iNode = iNode->getNext();
	}
	return size;
}
