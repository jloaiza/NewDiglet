#include "raidone.h"
#include "databuffer.h"
#include "../include/constants.h"
#include "../binaryoperations/byteshandler.h"
#include "../tokenizer/tokenizer.h"
#include <iostream>

const std::string RaidOne::ERROR_READING = "";

RaidOne::RaidOne(std::string pID, int pBlockSize){
	_id = pID;
	_maxSize = 0;
	_blockSize = pBlockSize;
	_raid = 1;
	_working = false;
	_functional = false;
	_files = new nTree(); //Sustituir más adelante por loadTree
	_diskList = new DoubleLinkedList<Disk, std::string>();
	_currentDisk = _diskList->getHead();
}

RaidOne::RaidOne(std::string pID, int pBlockSize, int pMaxSize, bool pFunctional, bool pWorking){
	_id = pID;
	_blockSize = pBlockSize;
	_maxSize = pMaxSize;
	_functional = pFunctional;
	_working = pWorking;
	_files = new nTree(); //Sustituir más adelante por loadTree
	_currentDisk = _diskList->getHead();
}

void RaidOne::startDiskGroup(){
	if (_functional){
		_working = true;
	}
}
	
void RaidOne::stopDiskGroup(){
	_working = false;
}

DataNode* RaidOne::getFile(iFile* pFile){

}

void RaidOne::deleteFile(nTreeNode* pNode){

}

nTreeNode* RaidOne::createFile(nTreeNode* pActual, std::string pName, RegisterSpace* pRegister, std::string pUser){
	std::cout<<"createFile"<<std::endl;
	DataBuffer header = DataBuffer(); //Almacenará la información del header

	std::cout<<"cf0"<<std::endl;
	//Tomar la información
	int dataReg = 0;
	int freeReg = 0;
	int lastReg = 0;
	int endReg = 0;
	int regSize = pRegister->getAllSize();
	short formatSize = pRegister->totalLength()*REGISTER_SIZE;

	std::cout<<"cf1"<<std::endl;
	//Agregar la informacion a los dataspaces
	header.addToBuffer(&pName, STRING, FILENAME_SIZE);
	header.addToBuffer(&pUser, STRING, AUTHOR_SIZE);
	header.addToBuffer(&dataReg, INT, BLOCKNEXT_SIZE);
	header.addToBuffer(&freeReg, INT, BLOCKNEXT_SIZE);
	header.addToBuffer(&lastReg, INT, BLOCKNEXT_SIZE);
	header.addToBuffer(&endReg, INT, BLOCKNEXT_SIZE);
	header.addToBuffer(&regSize, SHORT, REGS_SIZE);
	header.addToBuffer(&formatSize, SHORT, REGS_SIZE);

	std::cout<<"cf2"<<std::endl;
	//Cargar una representacion del register format como data nodes
	DataNode* regData = toDataNode(pRegister, REGCOL_SIZE, REGTYPE_SIZE, REGCOLSIZE_SIZE);

	//head va ser el string binario con todos los datos
	std::string head = toBinary(header.getBuffer());
	head += toBinary(regData);

	std::cout<<"cf3"<<std::endl;
	//Se divide el head en los espacios necesarios descontando el espacio ocupado por los siguientes bloques
	ListNode<std::string>* strips = getStrips(head, _blockSize-BLOCKNEXT_SIZE);

	std::cout<<"cf4"<<std::endl;
	//blocks contendrá los bloques donde son incertados los datos
	DoubleLinkedList<int, void> blocks = DoubleLinkedList<int, void>();

	ListNode<Disk>* tempStart = _currentDisk; //Copia del disco antes de empezar inserción

	//Insercion:
	while(strips != 0){
		//Verificación de que el disco esté disponible
		if (!_currentDisk->getData()->isAlive()){
			std::cout<<"?Error. Se ha perdido la conexión con el disco: "<<_currentDisk->getData()->getDiskDirection()<<"."<<std::endl;
			std::cout<<"El diskgroup: "<<_id<<" estará deshabilitado hasta que se repare el error."<<std::endl;
			_working = false;
			_functional = false;
			return 0;
		}
		//
		std::string toWrite = BytesHandler::bin2str(*strips->getData());
		std::cout<<"cf4.1"<<std::endl;
		int* ins = new int(_currentDisk->getData()->writeBlock(toWrite));
		std::cout<<"cf4.1.2"<<std::endl;
		if (*ins == 0){
			std::cout<<"?Error. No se pudo escribir en uno de los discos, la escritura será interrumpida."<<std::endl;
			std::cout<<"El archivo estaŕa corrupto."<<std::endl;
			std::cout<<"El diskgroup: '"<<_id<<"' estará deshabilitado hasta que se repare el error."<<std::endl;
			_working = false;
			_functional = false;
			return 0;
		}
		std::cout<<"cf4.1.3"<<std::endl;
		blocks.insertEnd(ins);
		std::cout<<"write block: "<<*ins<<std::endl;
		std::cout<<"cf4.2"<<std::endl;
		strips = strips->getNext();

		_currentDisk = getNextDisk(_currentDisk);
	}

	//Se crea el archivo para el árbol
	std::cout<<"cf5"<<std::endl;
	iFile* file = new iFile(tempStart->getData()->getDiskDirection(), -1, pRegister);
	ListNode<int>* iBlock = blocks.getHead();
	file->setStartBlock( *iBlock->getData() );

	std::cout<<"cf6"<<std::endl;
	//Se setean los bloques siguientes donde hubieron inserciones
	while (iBlock->getNext() != 0){
		int ip1, ip2, ip3, ip4;
		short disk;

		std::cout<<"cf6.1"<<std::endl;
		ip1 = std::stoi(Tokenizer::getCommandSpace(getNextDisk(tempStart)->getData()->getIp(), 1, '.'));
		ip2 = std::stoi(Tokenizer::getCommandSpace(getNextDisk(tempStart)->getData()->getIp(), 2, '.'));
		ip3 = std::stoi(Tokenizer::getCommandSpace(getNextDisk(tempStart)->getData()->getIp(), 3, '.'));
		ip4 = std::stoi(Tokenizer::getCommandSpace(getNextDisk(tempStart)->getData()->getIp(), 4, '.'));
		disk = getNextDisk(tempStart)->getData()->getDiskID();
		
		int nextBlock = *iBlock->getNext()->getData();

		std::cout<<"cf6.2"<<std::endl;
		std::string nextDir = "";
		nextDir += BytesHandler::unum2bin(ip1, 1);
		nextDir += BytesHandler::unum2bin(ip2, 1);
		nextDir += BytesHandler::unum2bin(ip3, 1);
		nextDir += BytesHandler::unum2bin(ip4, 1);
		nextDir += BytesHandler::unum2bin(disk, 2);
		nextDir += BytesHandler::unum2bin(nextBlock, 4);
		nextDir = BytesHandler::bin2str(nextDir);

		std::cout<<"cf6.3"<<std::endl;
		tempStart->getData()->writeBytes(*iBlock->getData(), _blockSize-BLOCKNEXT_SIZE, BLOCKNEXT_SIZE, nextDir);
		std::cout<<"cf6.4"<<std::endl;
		iBlock = iBlock->getNext();
		std::cout<<"cf6.5"<<std::endl;
	}
	std::cout<<"cf7"<<std::endl;
	//Se incerta el ifile en el árbol y se devuelve el nodo correspondiente
	_files->insert(file, pActual, pName, pUser, "");
	return _files->getNode(pActual, pName);
}

ListNode<Disk>* RaidOne::getNextDisk(ListNode<Disk>* pActual){
	if (pActual->getNext() == 0){
		return _diskList->getHead();
	} else {
		return pActual->getNext();
	}
}

std::string RaidOne::getDirectionBlockFromBin(std::string pBin){
	//Separar datos de la dirección 
	if (pBin.length() < 8){
		return "";
	}
	int ip1 = BytesHandler::to_ulong(pBin.substr(0, 8)); 
	int ip2 = BytesHandler::to_ulong(pBin.substr(8, 8));
	int ip3 = BytesHandler::to_ulong(pBin.substr(16, 8));
	int ip4 = BytesHandler::to_ulong(pBin.substr(24, 8));
	int diskID = BytesHandler::to_ulong(pBin.substr(32, 16));
	int block = BytesHandler::to_ulong(pBin.substr(48, 32));

	//Unir los datos
	std::string direction = std::to_string(ip1) + std::string(".") + std::to_string(ip2) + std::string(".") + std::to_string(ip3) + std::string(".") + std::to_string(ip4) + std::string(":") + std::to_string(diskID) + std::string(":") + std::to_string(block);
	if (pBin.length() > 80){
		std::cout<<"GetDir: "<<pBin.length();
		return direction + std::string(":") + std::to_string(BytesHandler::to_ulong(pBin.substr(80, 16)));
	} else {
		return direction;
	}
		
}

std::string RaidOne::getBinFromDirection(std::string pDirection){
	std::string ip = Tokenizer::getCommandSpace(pDirection, 1, ':');
	int disk = std::stoi( Tokenizer::getCommandSpace(pDirection, 2, ':') );
	int nextFreeBlock = std::stoi( Tokenizer::getCommandSpace(pDirection, 3, ':') );
	int nextFreeOffset = std::stoi( Tokenizer::getCommandSpace(pDirection, 4, ':') );

	int ip1 = std::stoi( Tokenizer::getCommandSpace(ip, 1, '.') );
	int ip2 = std::stoi( Tokenizer::getCommandSpace(ip, 2, '.') );
	int ip3 = std::stoi( Tokenizer::getCommandSpace(ip, 3, '.') );
	int ip4 = std::stoi( Tokenizer::getCommandSpace(ip, 4, '.') );

	std::string dir = "";
	dir += BytesHandler::unum2bin(ip1, 1);
	dir += BytesHandler::unum2bin(ip2, 1);
	dir += BytesHandler::unum2bin(ip3, 1);
	dir += BytesHandler::unum2bin(ip4, 1);
	dir += BytesHandler::unum2bin(disk, 2);
	dir += BytesHandler::unum2bin(nextFreeBlock, 4);
	dir += BytesHandler::unum2bin(nextFreeOffset, 4);

}

std::string RaidOne::getDataStartDirection(iFile* pFile){
	return getHeaderSpace(pFile, FILENAME_SIZE+AUTHOR_SIZE, DIRTOREG_SIZE);
}

std::string RaidOne::getHeaderSpace(iFile* pFile, int pPrevSize, int pReadSize){
	//Obtenemos el disco donde incia el header
	std::string currentDisk = pFile->getDisk();
	Disk* startDisk = _diskList->search(&currentDisk);
	if (startDisk == 0){
		return ERROR_READING;
	}

	//Se calcula la cantidad de bloques a recorrer hasta llegar al inicio de los datos
	int freePointerBlock = (pPrevSize)/(_blockSize-BLOCKNEXT_SIZE);
	int iBlock = pFile->getStartBlock(); //Bloque donde empiezan los datos

	int moves = 0; //Utilizada como condición de parada en el siguiente ciclo
	if ( pPrevSize%(_blockSize-BLOCKNEXT_SIZE) == 0 ){ //Quiere decir que el inicio de los datos está en el otro disco
		std::cout<<"HERE GHSP 1"<<std::endl;
		moves = -1; //Se debe realizar una iteración más hasta llegar al inicio
	}
	//Buscamos el disco correcto
	for (int i = freePointerBlock; i > moves; i--){
		std::cout<<"HERE GHSP 2 "<<i<<std::endl;
		std::string binDir = startDisk->readBytes(iBlock, _blockSize-BLOCKNEXT_SIZE, BLOCKNEXT_SIZE); //Dirección del siguiente bloque
		std::cout<<"HERE GHSP 2.1"<<std::endl;
		std::string direction = getDirectionBlockFromBin(binDir);
		if (direction == ""){
			std::cout<<"HERE GHSP 2.1 sss"<<std::endl;
			return "0";
		}
		std::cout<<"HERE GHSP 2.2 Direcction: "<<direction<<std::endl;
		std::string nextDisk = direction.substr(0, Tokenizer::charIndex(direction, ':', 2));
		std::cout<<"HERE GHSP 2.3"<<std::endl;
		int block = std::stoi( Tokenizer::getCommandSpace(direction, 3, ':') );
		std::cout<<"HERE GHSP 2.4"<<std::endl;
		
		//Setear los siguientes
		startDisk = _diskList->search(&nextDisk);
		iBlock = block;
		if (startDisk == 0){
			std::cout<<"Disco == 0 en getDataStartBlock"<<std::endl;
			return ERROR_READING;
		}
	}
	std::cout<<"HERE GHSP 3"<<std::endl;
	int freeInfoPos = pPrevSize%(_blockSize-BLOCKNEXT_SIZE);
	std::string binDir;
	if ( (freeInfoPos+pReadSize) > (_blockSize-BLOCKNEXT_SIZE) ){
		std::cout<<"HERE GHSP 4"<<std::endl;
		binDir = startDisk->readBytes(iBlock, freeInfoPos, (_blockSize-BLOCKNEXT_SIZE)-freeInfoPos);
		std::string binDir = startDisk->readBytes(iBlock, _blockSize-BLOCKNEXT_SIZE, BLOCKNEXT_SIZE); //Dirección del siguiente bloque
		std::string direction = getDirectionBlockFromBin(binDir);
		std::string nextDisk = direction.substr(0, Tokenizer::charIndex(direction, ':', 2));
		int block = std::stoi( Tokenizer::getCommandSpace(direction, 3, ':') );

		binDir += startDisk->readBytes(block, 0, (freeInfoPos+pReadSize) - (_blockSize-BLOCKNEXT_SIZE) );
		std::cout<<"HERE GHSP 4.1"<<std::endl;
	} else {
		std::cout<<"HERE GHSP 5"<<std::endl;
		binDir = startDisk->readBytes(iBlock, freeInfoPos, pReadSize);
		std::cout<<"HERE GHSP 5.1"<<std::endl;
	}
	
	return getDirectionBlockFromBin(binDir);
}

void RaidOne::writeDataStart(iFile* pFile, std::string pData){
	writeToHeader(pFile, FILENAME_SIZE+AUTHOR_SIZE, DIRTOREG_SIZE, pData);
}

void RaidOne::writeFreeSpace(iFile* pFile, std::string pData){
	writeToHeader(pFile, FILENAME_SIZE+AUTHOR_SIZE+DIRTOREG_SIZE, DIRTOREG_SIZE, pData);
}

void RaidOne::writeLastData(iFile* pFile, std::string pData){
	writeToHeader(pFile, FILENAME_SIZE+AUTHOR_SIZE+2*DIRTOREG_SIZE, DIRTOREG_SIZE, pData);
}

void RaidOne::writeEndSpace(iFile* pFile, std::string pData){
	writeToHeader(pFile, FILENAME_SIZE+AUTHOR_SIZE+3*DIRTOREG_SIZE, DIRTOREG_SIZE, pData);
}

void RaidOne::writeToHeader(iFile* pFile, int pOffset, int pSize, std::string pData){
	std::string diskID = pFile->getDisk();
	Disk* disk = _diskList->search(&diskID);
	int startBlock = pFile->getStartBlock();
	disk->writeBytes(startBlock, pOffset, pSize, pData);
}


std::string RaidOne::getFreeReg(iFile* pFile){	
	std::cout<<"GFB 1"<<std::endl;
	std::string freeDirection = getHeaderSpace(pFile, FILENAME_SIZE+AUTHOR_SIZE+DIRTOREG_SIZE, DIRTOREG_SIZE);
	std::cout<<"GFB 2: " <<freeDirection<<std::endl;
	if (freeDirection == "0"){
		return "";

	} else {
		std::cout<<"GFB 3"<<std::endl;
		std::string nextFreeDisk = freeDirection.substr(0, Tokenizer::charIndex(freeDirection, ':', 2));
		int nextFreeBlock = std::stoi( Tokenizer::getCommandSpace(freeDirection, 3, ':') );
		int nextFreeOffset = std::stoi( Tokenizer::getCommandSpace(freeDirection, 4, ':') );
		std::cout<<"GFB 4"<<std::endl;
		Disk* freeDisk = _diskList->search(&nextFreeDisk);
		std::string nextFreeDirBin = freeDisk->readBytes(nextFreeBlock, nextFreeOffset, DIRTOREG_SIZE);
		writeFreeSpace(pFile, nextFreeDirBin);
	}

	return freeDirection;
}

std::string RaidOne::getLastReg(iFile* pFile){
	return getHeaderSpace(pFile, FILENAME_SIZE+AUTHOR_SIZE+2*DIRTOREG_SIZE, DIRTOREG_SIZE);

}

std::string RaidOne::getEndReg(iFile* pFile){
	return getHeaderSpace(pFile, FILENAME_SIZE+AUTHOR_SIZE+3*DIRTOREG_SIZE, DIRTOREG_SIZE);
}

short RaidOne::apendReg(DataNode* pData, iFile* pFile){	
	std::cout<<"AR 1"<<std::endl;
	std::string binMessage = BytesHandler::bin2str(toBinary(pData));
	std::cout<<"AR 1.1.5"<<std::endl;
	std::string freeReg = getFreeReg(pFile);
	std::cout<<"AR 1.1"<<std::endl;
	std::string lastReg = getLastReg(pFile);
	std::string lastRegBin = getBinFromDirection(lastReg);
	std::cout<<"AR 1.2"<<std::endl;
	binMessage = lastRegBin + binMessage + getBinFromDirection("");
	int dataSize = pData->getAllDataSize();
	std::string lastDirLink;

	std::cout<<"AR 2"<<std::endl;
	if (freeReg == ""){
		std::cout<<"AR 3"<<std::endl;
		if (lastReg != ""){
			std::string endDir = getEndReg(pFile);
			int endOffset = std::stoi( Tokenizer::getCommandSpace(endDir, 4, ':'));
			if (endOffset+(2*DIRTOREG_SIZE+dataSize) <= _blockSize){

				std::string endDiskID = endDir.substr(0, Tokenizer::charIndex(endDir, ':', 2));
				int endBlock = std::stoi( Tokenizer::getCommandSpace(endDir, 3, ':'));
				int endOffset = std::stoi( Tokenizer::getCommandSpace(endDir, 4, ':'));

				Disk* endDisk = _diskList->search(&endDiskID);
				endDisk->writeBytes(endBlock, endOffset+2*DIRTOREG_SIZE+dataSize, 2*DIRTOREG_SIZE+dataSize, binMessage);

				lastRegBin = getBinFromDirection( endDir.substr(0, Tokenizer::charIndex(endDir, ':', 3)) + std::string(":") + std::to_string(endOffset+2*DIRTOREG_SIZE+dataSize) );
				writeEndSpace(pFile, lastRegBin);
			} else {
				int insertBlock = _currentDisk->getData()->writeBlock(binMessage);
				lastDirLink = getBinFromDirection( _currentDisk->getData()->getDiskDirection() + std::string(":") + std::to_string(insertBlock) + std::string(":") + std::string("0") );
				_currentDisk = getNextDisk(_currentDisk);
				writeEndSpace(pFile, lastRegBin);
			}

		} else {
			std::cout<<"AR 4"<<std::endl;
			int insertBlock = _currentDisk->getData()->writeBlock(binMessage);
			lastDirLink = getBinFromDirection(_currentDisk->getData()->getDiskDirection() + std::string(":") + std::to_string(insertBlock) + std::string(":") + std::string("0"));
			_currentDisk = getNextDisk(_currentDisk);
		}

	} else {
		std::cout<<"AR 5"<<std::endl;
		std::string freeDiskID = freeReg.substr(0, Tokenizer::charIndex(freeReg, ':', 2));
		int freeBlock = std::stoi( Tokenizer::getCommandSpace(freeReg, 3, ':'));
		int freeOffset = std::stoi( Tokenizer::getCommandSpace(freeReg, 4, ':'));
		
		Disk* freeDisk = _diskList->search(&freeDiskID);
		freeDisk->writeBytes(freeBlock, freeOffset, dataSize, binMessage);

		lastDirLink = getBinFromDirection(freeReg);
	}

	if (lastReg != ""){
		std::cout<<"AR 6"<<std::endl;
		std::string lastDiskID = lastReg.substr(0, Tokenizer::charIndex(lastReg, ':', 2));
		int lastBlock = std::stoi( Tokenizer::getCommandSpace(lastReg, 3, ':'));
		int lastOffset = std::stoi( Tokenizer::getCommandSpace(lastReg, 4, ':'));
		Disk* lastDisk = _diskList->search(&lastDiskID);
		lastDisk->writeBytes(lastBlock, lastOffset+DIRTOREG_SIZE+dataSize, DIRTOREG_SIZE, lastDirLink);

	} else {
		std::cout<<"AR 7"<<std::endl;
		writeDataStart(pFile, lastDirLink);
		writeLastData(pFile, lastDirLink);
	}

}

short RaidOne::writeReg(int pRegisterNumber, DataNode* pData, iFile* pFile){

}

DataNode* RaidOne::readReg(int pRegisterNumber, iFile* pFile){

}

void RaidOne::eraseReg(int pRegisterNumber, iFile* pFile){

}

RegisterSpace* RaidOne::getRegFormat(iFile* pFile){

}

void RaidOne::format(){
	_functional = true;
	ListNode<Disk>* iNode = _diskList->getHead();
	while(iNode != 0){
		iNode->getData()->format(_blockSize);
		iNode = iNode->getNext();
	}
	_currentDisk = _diskList->getHead();
}

void RaidOne::eraseFile(iFile* pFile){

}