#include "session.h"
#include <iostream>

Session::Session(int pSessionID){
	_id = pSessionID;
	_lss = new DoubleLinkedList<Lss, short>();
}

Lss* Session::getLss(short pID) const{
	return _lss->search(&pID);
}

void Session::addLss(Lss* pLss){
	_lss->insertEnd(pLss);
}

bool Session::operator==(int& pSession){
	return _id == pSession;
}

bool Session::operator!=(int& pSession){
	return _id != pSession;
}

bool Session::operator<=(int& pSession){
	return _id <= pSession;
}

bool Session::operator<(int& pSession){
	return _id < pSession;
}

bool Session::operator>=(int& pSession){
	return _id >= pSession;
}

bool Session::operator>(int& pSession){
	return _id > pSession;
}


bool Session::operator==(Session& pSession){
	return _id == pSession.getID();
}

bool Session::operator!=(Session& pSession){
	return _id != pSession.getID();
}

bool Session::operator<=(Session& pSession){
	return _id <= pSession.getID();
}

bool Session::operator<(Session& pSession){
	return _id < pSession.getID();
}

bool Session::operator>=(Session& pSession){
	return _id >= pSession.getID();
}

bool Session::operator>(Session& pSession){
	return _id > pSession.getID();
}