#include "lssmanager.h"

int main(){
	LssManager lssManager;
	lssManager.startSystem();
}